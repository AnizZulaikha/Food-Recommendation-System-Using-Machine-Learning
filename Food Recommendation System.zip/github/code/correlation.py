
def lunch_food_Name(foodUIM, foodNamess):
    foodRatings = foodUIM[f'{foodNamess}']
    return foodRatings

def dinner_food_Name(foodUIM, foodNamess):
    foodRatings = foodUIM[f'{foodNamess}']
    return foodRatings

def lunch_drinks_name(drinksUIM, drinkNamess):
    drinkRatings = drinksUIM[f'{drinkNamess}']
    return drinkRatings

def dinner_drinks_name(drinksUIM, drinkNamess):
    drinkRatings = drinksUIM[f'{drinkNamess}']
    return drinkRatings




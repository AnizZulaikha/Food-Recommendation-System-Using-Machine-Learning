import pyqt5
import pyqt5-tools
import pandas
import matplotlib
import seaborn